package com.example.testservice;

import java.util.LinkedList;

public class ServiceLogic implements Runnable {
	
	private LinkedList<Client> clients;
	private LinkedList<Station> stations;
	
	public ServiceLogic(){
		
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
