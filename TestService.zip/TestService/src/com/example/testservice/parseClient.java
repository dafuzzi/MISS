package com.example.testservice;

public class parseClient {

}
